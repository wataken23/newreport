#ifndef AUTO_MAILDIR_H
#define AUTO_MAILDIR_H

extern char auto_maildir[];

#endif
