exec 2>&1
exec tcpserver -DRHv -xrules.cdb -llocalhost 0 110 \
softlimit -m 3000000 \
QMAIL/bin/qmail-popup `cat QMAIL/control/me` \
HOME/bin/selectcheckpw \
HOME/bin/loginlog \
QMAIL/bin/qmail-pop3d MAILDIR
