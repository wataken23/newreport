echo "$TCPREMOTEIP" "$TCPLOCALPORT" "$USER" | QMAIL/bin/splogger login 2
pop="$1"; shift; exec "$pop" "$@"
