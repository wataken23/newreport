#include "auto_home.h"

void hier()
{
  c(auto_home,"bin","checkpw",-1,-1,0700);
  c(auto_home,"bin","checkapoppw",-1,-1,0700);
  c(auto_home,"bin","selectcheckpw",-1,-1,0700);
  c(auto_home,"bin","loginlog",-1,-1,0755);
}
