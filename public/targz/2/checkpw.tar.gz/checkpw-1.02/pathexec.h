#ifndef PATHEXEC_H
#define PATHEXEC_H

extern void pathexec_run(char *,char **,char **);
extern int pathexec_env(char *,char *);
extern void pathexec(char **);

#endif
