exec 2>&1
exec tcpserver -DRHv -llocalhost 0 110 \
softlimit -m 3000000 \
QMAIL/bin/qmail-popup `cat QMAIL/control/me` \
HOME/bin/checkpw \
HOME/bin/loginlog \
sh -c '
if [ -n "$EXT" ]; then dashext=-"$EXT"; fi
exec QMAIL/bin/qmail-pop3d MAILDIR"$dashext"
'
