#ifndef AUTO_HOME_H
#define AUTO_HOME_H

extern const char auto_home[];

#endif
