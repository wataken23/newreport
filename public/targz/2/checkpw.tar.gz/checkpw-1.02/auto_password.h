#ifndef AUTO_PASSWORD_H
#define AUTO_PASSWORD_H

extern char auto_password[];

#endif
