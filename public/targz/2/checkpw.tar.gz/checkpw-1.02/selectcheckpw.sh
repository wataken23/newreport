case "$AUTH" in
apop)
    exec HOME/bin/checkapoppw $*
    ;;
pop)
    exec HOME/bin/checkpw $*
    ;;
*)
    exit 1
    ;;
esac
